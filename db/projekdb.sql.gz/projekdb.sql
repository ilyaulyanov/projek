-- phpMyAdmin SQL Dump
-- version 4.2.8
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Dec 04, 2014 at 10:34 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `projek`
--
DROP DATABASE `projek`;
CREATE DATABASE IF NOT EXISTS `projek` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `projek`;

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE IF NOT EXISTS `notes` (
`note_id` int(11) NOT NULL,
  `note_text` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='user data';

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`note_id`, `note_text`, `user_id`) VALUES
(1, 'Projek', 3),
(2, 'Project', 3),
(3, 'yah', 6),
(4, 'fsafas', 6),
(5, 'fsafffff', 6),
(6, 'alal', 6),
(7, '', 6),
(8, 'My Project', 6);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
`project_id` int(11) NOT NULL,
  `project_name` varchar(32) NOT NULL,
  `project_description` text NOT NULL COMMENT 'project user description',
  `deadline` date NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'User id to associate with project id'
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`project_id`, `project_name`, `project_description`, `deadline`, `user_id`) VALUES
(52, 'My project', 'Test project for Ilya', '0000-00-00', 6);

-- --------------------------------------------------------

--
-- Table structure for table `projects_stages`
--

CREATE TABLE IF NOT EXISTS `projects_stages` (
  `project_id` int(11) NOT NULL,
  `stage_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `projects_stages`
--

INSERT INTO `projects_stages` (`project_id`, `stage_id`) VALUES
(52, 40),
(52, 41),
(52, 42);

-- --------------------------------------------------------

--
-- Table structure for table `stages`
--

CREATE TABLE IF NOT EXISTS `stages` (
`stage_id` int(11) NOT NULL,
  `stage_name` varchar(64) NOT NULL,
  `deadline` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stages`
--

INSERT INTO `stages` (`stage_id`, `stage_name`, `deadline`) VALUES
(40, 'Design', '0000-00-00'),
(41, 'Development', '0000-00-00'),
(42, 'Testing', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `stages_tasks`
--

CREATE TABLE IF NOT EXISTS `stages_tasks` (
  `stage_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stages_tasks`
--

INSERT INTO `stages_tasks` (`stage_id`, `task_id`) VALUES
(40, 78),
(40, 79),
(41, 80),
(42, 81);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
`task_id` int(11) NOT NULL,
  `task_name` varchar(64) NOT NULL,
  `task_completion` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`task_id`, `task_name`, `task_completion`) VALUES
(78, 'Prototyping', 15),
(79, 'Wireframe', 25),
(80, 'Working Prototype', 40),
(81, 'Unit Testing', 50);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`user_id` int(11) NOT NULL COMMENT 'auto incrementing user_id of each user, unique index',
  `user_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'user''s name, unique',
  `user_password_hash` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'user''s password in salted and hashed format',
  `user_email` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'user''s email, unique',
  `user_active` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'user''s activation status',
  `user_account_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'user''s account type (basic, premium, etc)',
  `user_has_avatar` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 if user has a local avatar, 0 if not',
  `user_rememberme_token` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'user''s remember-me cookie token',
  `user_creation_timestamp` bigint(20) DEFAULT NULL COMMENT 'timestamp of the creation of user''s account',
  `user_last_login_timestamp` bigint(20) DEFAULT NULL COMMENT 'timestamp of user''s last login',
  `user_failed_logins` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'user''s failed login attempts',
  `user_last_failed_login` int(10) DEFAULT NULL COMMENT 'unix timestamp of last failed login attempt',
  `user_activation_hash` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'user''s email verification hash string',
  `user_password_reset_hash` char(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'user''s password reset code',
  `user_password_reset_timestamp` bigint(20) DEFAULT NULL COMMENT 'timestamp of the password reset request',
  `user_provider_type` text COLLATE utf8_unicode_ci,
  `user_facebook_uid` bigint(20) unsigned DEFAULT NULL COMMENT 'optional - facebook UID'
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='user data';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_password_hash`, `user_email`, `user_active`, `user_account_type`, `user_has_avatar`, `user_rememberme_token`, `user_creation_timestamp`, `user_last_login_timestamp`, `user_failed_logins`, `user_last_failed_login`, `user_activation_hash`, `user_password_reset_hash`, `user_password_reset_timestamp`, `user_provider_type`, `user_facebook_uid`) VALUES
(4, 'Gordon', '$2y$10$l/0n2DOGAScgunRvaiQdyuPrAqbEH/x4dI5cOc/ZxIju/gqk0H96O', 'gordon.lee147@gmail.com', 1, 1, 0, NULL, 1415311271, 1415311359, 0, NULL, NULL, NULL, NULL, 'DEFAULT', NULL),
(5, 'Rob', '$2y$10$vFqpZX16i4VuBncCzG7NxeuKQmclhYNJlblCt73qmO55SlVRZ6E3W', 'buddy@test.com', 0, 1, 0, NULL, 1415313599, NULL, 0, NULL, '56b8e417e126f958df60c5f8dff55a4ae210e849', NULL, NULL, 'DEFAULT', NULL),
(6, 'ilya', '$2y$10$hKjC6w455Z8Ua1Kh6oQkguchISfuCj8DAvxBATlM3j.Kw554n/2CK', 'ilya.wt@gmail.com', 1, 1, 1, '2507b10ddaf04e06bd16c5fdf23067500586ac4f5f8aeb1b0285d62882edb165', 1415478940, 1417637170, 0, NULL, NULL, NULL, NULL, 'DEFAULT', NULL),
(7, 'Ilya de Loco', '$2y$10$xpEGn7ZW4THdFNsUOhyy5usOLJgk07s.nr9aIBA19IrdyBbj5LX3u', 'b3270254@trbvm.com', 1, 1, 1, '53e7c5512f22d3195118268a6e19585b881a192d6a4e190febfc34919eb7e456', 1416506376, 1416506451, 0, NULL, NULL, NULL, NULL, 'DEFAULT', NULL),
(8, 'tomthechaone', '$2y$10$yGVKLoinGudV318loAN.ye2Z1VFfJ/EcZrGoJvDO8UD.mmylVvZEe', 'thechaone@gmail.com', 1, 1, 0, NULL, 1417110733, 1417110856, 0, NULL, NULL, NULL, NULL, 'DEFAULT', NULL),
(9, 'kuo123', '$2y$10$4zpHvUU.CiZYAqCqIkQgdu1YB8PziF6rvI8B00KuLjOg5cIVha6Dm', 'c184827@trbvm.com', 1, 1, 1, NULL, 1417112033, 1417112106, 0, NULL, NULL, NULL, NULL, 'DEFAULT', NULL),
(10, 'Butt Soup Barnes', '$2y$10$gZzJq5DExt.cyriL9o1Ef.EjqH3bvDbwNMQYgy6FvjmDw.pAQ.kQC', 'jessewood24@hotmail.com', 1, 1, 1, NULL, 1417112766, 1417112839, 0, NULL, NULL, NULL, NULL, 'DEFAULT', NULL),
(11, 'AnishChandra01', '$2y$10$jD8.Eb1JmlhkXaQgQe0LMOcgx57QYid.6lybPPgVFaOC3dV8n852.', 'anishschandra@gmail.com', 1, 1, 1, NULL, 1417113990, 1417114072, 0, NULL, NULL, NULL, NULL, 'DEFAULT', NULL),
(12, '', '$2y$10$yuyMI2GDcDQrC8im9281Ze46BnhPbk2QQ8fTxtJyETNc.vKtI.9v6', 'a@ann.com', 0, 1, 0, NULL, 1417116039, NULL, 0, NULL, '45149051d5eebd677c199c009e8622fb10b60848', NULL, NULL, 'DEFAULT', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_projects`
--

CREATE TABLE IF NOT EXISTS `users_projects` (
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
 ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
 ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `stages`
--
ALTER TABLE `stages`
 ADD PRIMARY KEY (`stage_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
 ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`user_id`), ADD UNIQUE KEY `user_email` (`user_email`), ADD KEY `user_facebook_uid` (`user_facebook_uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
MODIFY `note_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `stages`
--
ALTER TABLE `stages`
MODIFY `stage_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=82;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incrementing user_id of each user, unique index',AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
